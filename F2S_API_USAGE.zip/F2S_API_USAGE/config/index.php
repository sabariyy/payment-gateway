<?php
error_reporting(0);
// admin key 
define("ADMIN_KEY", ""); // ADMIN KEY

// payout service credentials
define('MID', ''); // MERCHANT ID
define('MKEY', ''); // MERCHANT KEY
define('GUID', ''); // SUB WALLET GUID

// accept payment gateway credentials
define('GPIN', ''); // GPIN
define('TOKENID', ''); // TOKEN ID
define("CPIN", ""); // CPIN
?>